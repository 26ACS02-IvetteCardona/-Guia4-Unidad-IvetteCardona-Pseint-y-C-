﻿internal class Program
{
    private static void Main(string[] args)
    {
        int num;

        Console.WriteLine("Nombre: Ivette Cardona");

        for (num = 1; num <= 20; num++)
        {
            Console.WriteLine(num * 4);

        }
    }
}