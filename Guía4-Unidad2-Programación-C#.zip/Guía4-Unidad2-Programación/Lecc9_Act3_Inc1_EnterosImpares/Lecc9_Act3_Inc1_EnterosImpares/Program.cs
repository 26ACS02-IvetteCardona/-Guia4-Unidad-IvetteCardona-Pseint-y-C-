﻿internal class Program
{
    private static void Main(string[] args)
    {
        int N;
        int contador = 20;
               
        Console.WriteLine("Ingresa un número que sea mayor a 20: ");
        N = int.Parse(Console.ReadLine());

        while (contador <= N)
        {
            if (contador % 2 != 0)
            {
                Console.WriteLine(contador);
            }
            contador = contador + 1;
        }
    }
}