﻿internal class Program
{
    private static void Main(string[] args)
    {
        int num, i, contador, suma;

        suma = 0;

        Console.WriteLine("Presione ENTER para mostrar los números primos del 1 al 22");
        Console.ReadKey();

        for (num = 1; num <= 22; num++)
        {
            contador = 0;

            for (i = 1; i <= num; i++)
            {
                if (num % i == 0)
                {
                    contador++;
                }
            }

            if (contador == 2)
            {
                Console.WriteLine("Numero primo: " + num);

                suma = suma + num;
            }
        }

        Console.WriteLine("Presione S para mostrar la suma de los números");
        Console.ReadKey();
        Console.WriteLine("La suma de los numeros primos es: " + suma);
    }
}