﻿internal class Program
{
    private static void Main(string[] args)
    {
        int num, i, contador;
        int suma = 0;

        Console.WriteLine("Números primos del 1 al 50 y su suma");

        for (num = 1; num <= 50; num++)
        {
            contador = 0;

            for (i = 1; i <= num; i++)
            {
                if (num % i == 0)
                {
                    contador++;
                }
            }

            if (contador == 2)
            {
                Console.WriteLine("Numero primo: " + num);

                suma = suma + num;
            }
        }

        Console.WriteLine("La suma de los numeros primos es: " + suma);
    }
}