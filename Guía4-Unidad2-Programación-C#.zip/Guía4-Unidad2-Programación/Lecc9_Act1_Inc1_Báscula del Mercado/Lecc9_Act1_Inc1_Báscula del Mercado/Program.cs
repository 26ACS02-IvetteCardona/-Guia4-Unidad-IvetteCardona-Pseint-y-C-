﻿internal class Program
{
    private static void Main(string[] args)
    {
        int pesoAcumulado = 0;
        int pesoManzana;
        int contarManzanas = 0;

        Console.WriteLine("*================BÁSCULA DEL MERCADO================*");
        while (pesoAcumulado < 1000)
        {
            Console.WriteLine("Ingrese el peso de la manzana en gramos (100-300)");
            pesoManzana = int.Parse(Console.ReadLine());

            if (pesoManzana >= 100 && pesoManzana <= 300)
            {
                pesoAcumulado = pesoAcumulado + pesoManzana;
                Console.WriteLine("Peso Actual: " + pesoAcumulado + " gramos");
                contarManzanas = contarManzanas + 1;
            }
            else
            {
                Console.WriteLine("Error: Esa manzana no cumple con el peso solicitado");
            }
        }

        Console.WriteLine("¡Meta alcanzada! Ya tiene " + pesoAcumulado / 1000 + " kilos en la bolsa.");
        Console.WriteLine("Usted acumulo " + contarManzanas + "manzanas");
    }
}