﻿internal class Program
{
    private static void Main(string[] args)
    {
        int num, i, factorial;

        factorial = 1;

        Console.WriteLine("¡Encuentra el factorial de un número!");

        Console.WriteLine("Ingrese un numero:");
        num = int.Parse(Console.ReadLine());

        for (i = 1; i <= num; i++)
        {
            factorial = factorial * i;
        }

        Console.WriteLine("El factorial es: " + factorial);
    }
}