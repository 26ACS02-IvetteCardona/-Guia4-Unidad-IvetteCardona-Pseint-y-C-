﻿internal class Program
{
    private static void Main(string[] args)
    {
        int num, i;
        int suma = 0;

        Console.WriteLine("¡Bienvenid@! Para hacerme funcionar, presiona SPACE");
        Console.ReadKey();

        Console.WriteLine("Ingrese un numero:");
        num = int.Parse(Console.ReadLine());

        for (i = num; i >= 1; i--)
        {
            Console.WriteLine(i);

            suma = suma + i;
        }

        Console.WriteLine("La suma es: " + suma);
    }
}