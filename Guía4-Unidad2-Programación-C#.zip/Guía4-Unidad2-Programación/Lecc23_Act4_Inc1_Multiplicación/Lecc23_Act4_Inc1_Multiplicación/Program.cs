﻿internal class Program
{
    private static void Main(string[] args)
    {
        int num, i, resultado;

        Console.WriteLine("¡Bienvenido!");

        Console.WriteLine("Ingresa un numero y te mostraré la tabla :)");
        num = int.Parse(Console.ReadLine());

        for (i = 1; i <= 10; i++)
        {
            resultado = num * i;

            Console.WriteLine(num + " x " + i + " = " + resultado);
        }
    }
}