﻿internal class Program
{
    private static void Main(string[] args)
    {
        int corte;

        Console.WriteLine("Nombre: Ivette Cardona");

        for (corte = 1; corte <= 8; corte++)
        {
            Console.WriteLine("Presione 0 para marcar su sello en la cuponera");
            Console.ReadKey();

            Console.WriteLine("Sello obtenido en el corte: " + corte);
        }

        Console.WriteLine("Obtener corte gratis");
    }
}