﻿internal class Program
{
    private static void Main(string[] args)
    {
        int monedas = 0;
        int nivel;
        int ganancia;

        Console.WriteLine("*****************WELCOME TO TEMPLE RUN****************");
        Console.WriteLine("¿Quieres subir de nivel? ¡Dime cuántas monedas has ganado!");
        monedas = int.Parse(Console.ReadLine());

        while (monedas < 350)
        {
            Console.WriteLine("Nivel 5 BLOQUEADO, tienes: "+monedas+" monedas.");
            Console.WriteLine("Ingresa cuántas monedas ganaste en esta partida: ");
            ganancia = int.Parse(Console.ReadLine());

            monedas = monedas + ganancia;
        }
        Console.WriteLine("¡Felicidades! Tienes "+monedas+" monedas.");
        Console.WriteLine("¡Has desbloqueado el nivel 5!");
    }

}