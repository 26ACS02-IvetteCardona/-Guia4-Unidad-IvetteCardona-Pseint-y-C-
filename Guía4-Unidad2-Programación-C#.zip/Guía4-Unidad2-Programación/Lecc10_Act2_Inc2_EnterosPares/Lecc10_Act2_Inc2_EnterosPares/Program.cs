﻿internal class Program
{
    private static void Main(string[] args)
    {
        int num, i;

        Console.WriteLine("Nombre: Ivette Cardona");

        Console.WriteLine("Ingrese un numero:");
        num = int.Parse(Console.ReadLine());

        for (i = 2; i <= num; i = i + 2)
        {
            Console.WriteLine(i);
        }
    }
}