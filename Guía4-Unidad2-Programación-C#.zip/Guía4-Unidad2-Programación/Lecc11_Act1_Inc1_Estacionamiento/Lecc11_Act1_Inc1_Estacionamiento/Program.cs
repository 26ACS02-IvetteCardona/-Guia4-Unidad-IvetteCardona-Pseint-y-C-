﻿internal class Program
{
    private static void Main(string[] args)
    {
        int cajones;

        cajones = 200;

        Console.WriteLine("Estacionamiento Libre");

        do
        {
            Console.WriteLine("Si desea saber cuántos estacionamientos quedan libres, presione ENTER");
            Console.ReadKey();


            Console.WriteLine("Cajones disponibles: " + cajones);

            cajones--;
        }
        while (cajones > 0);

        Console.WriteLine("Ya no hay cajones libres");

    }
}