﻿internal class Program
{
    private static void Main(string[] args)
    {
        int billete, i;
        int cantidad100 = 0;
        int total = 0;

        Console.WriteLine("¡Bienvendio al Cajero del Supermercado!");

        for (i = 1; i <= 10; i++)
        {
            Console.WriteLine("Ingrese el valor del billete:");
            billete = int.Parse(Console.ReadLine());

            total = total + billete;

            if (billete == 100)
            {
                cantidad100++;
            }
        }

        Console.WriteLine("Cantidad de billetes de 100: " + cantidad100);
        Console.WriteLine("Dinero total: $" + total);
    }
}