﻿internal class Program
{
    private static void Main(string[] args)
    {
        int num;
        int div = 1;
        int cantdiv = 0;

        Console.WriteLine("Ingresa un número positivo y entero: ");
        num = int.Parse(Console.ReadLine());

        while (div <= num)
        {
            if (num % div == 0) 
            {
                cantdiv = cantdiv + 1;
            }
            div = div + 1; 
        }

        if (cantdiv == 2)
        {
            Console.WriteLine("El número " + num + " es primo");
        }
        else
        {
            Console.WriteLine("El número " + num + " NO es Primo");
        }
    }
}