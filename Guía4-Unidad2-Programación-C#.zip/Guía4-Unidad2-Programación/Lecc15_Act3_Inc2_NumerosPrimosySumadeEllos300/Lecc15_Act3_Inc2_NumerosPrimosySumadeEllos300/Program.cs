﻿internal class Program
{
    private static void Main(string[] args)
    {
        int num, i, contador;
        int cantidadPrimos = 0;
        int sumaPares = 0;

        Console.WriteLine("Para iniciar el programa, presione ENTER");
        Console.ReadKey();

        for (num = 300; num >= 1; num--)
        {
            contador = 0;

            for (i = 1; i <= num; i++)
            {
                if (num % i == 0)
                {
                    contador++;
                }
            }

            if (contador == 2)
            {
                cantidadPrimos++;
            }

            if (num % 2 == 0)
            {
                sumaPares = sumaPares + num;
            }
        }

        Console.WriteLine("Cantidad de numeros primos: " + cantidadPrimos);
        Console.WriteLine("La suma de los pares es: " + sumaPares);
    }
}