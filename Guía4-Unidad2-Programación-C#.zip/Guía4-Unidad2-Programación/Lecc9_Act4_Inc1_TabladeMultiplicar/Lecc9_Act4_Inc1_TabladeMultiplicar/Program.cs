﻿internal class Program
{
    private static void Main(string[] args)
    {
        int num;
        int contador = 1;
        int resultado;

        Console.WriteLine("Dime el número para brindarte la tabla: ");
        num = int.Parse(Console.ReadLine());


        while (contador <= 10)
        {
            resultado = num * contador;
            Console.WriteLine(num + " x " + contador + " = " + resultado);

            contador = contador + 1;
        }
    }
}