﻿internal class Program
{
    private static void Main(string[] args)
    {
        int opcion;
        int boletosAdulto = 0;
        int boletosNino = 0;
        int totalBoletos = 0;
        double totalDinero = 0;

        Console.WriteLine("¡Bienvendio! Ingresa el número de la opción que deseas");

        do
        {
            Console.WriteLine("1. Boleto adulto");
            Console.WriteLine("2. Boleto niño");
            Console.WriteLine("3. Cuentas");
            opcion = int.Parse(Console.ReadLine());

            switch (opcion)
            {
                case 1:
                    boletosAdulto++;
                    totalBoletos++;
                    totalDinero += 15;
                    break;

                case 2:
                    boletosNino++;
                    totalBoletos++;
                    totalDinero += 10;
                    break;

                case 3:
                    Console.WriteLine("Fin de ventas");
                    break;

                default:
                    Console.WriteLine("Opcion no valida");
                    break;
            }

        } while (opcion != 3);

        Console.WriteLine("Boletos de adulto vendidos: " + boletosAdulto);
        Console.WriteLine("Boletos de niño vendidos: " + boletosNino);
        Console.WriteLine("Total de boletos vendidos: " + totalBoletos);
        Console.WriteLine("Total de dinero cobrado: $" + totalDinero);
    }
}