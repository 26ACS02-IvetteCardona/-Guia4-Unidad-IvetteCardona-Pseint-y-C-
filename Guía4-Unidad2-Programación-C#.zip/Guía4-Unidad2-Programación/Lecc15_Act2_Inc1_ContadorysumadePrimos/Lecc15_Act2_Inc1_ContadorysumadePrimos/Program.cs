﻿internal class Program
{
    private static void Main(string[] args)
    {
        int num, i, contador;
        int cantidad = 0;
        int suma = 0;

        Console.WriteLine("Para saber cuántos números primos hay entre 1 y 100, presiona SPACE");
        Console.ReadKey();

        for (num = 1; num <= 100; num++)
        {
            contador = 0;

            for (i = 1; i <= num; i++)
            {
                if (num % i == 0)
                {
                    contador++;
                }
            }

            if (contador == 2)
            {
                cantidad++;
                suma = suma + num;
            }
        }

        Console.WriteLine("Cantidad de numeros primos: " + cantidad);
        Console.WriteLine("Para saber la suma de los números, presiona el signo +");
        Console.ReadKey();
        Console.WriteLine("La suma de los numeros primos es: " + suma);
    }
}