﻿internal class Program
{
    private static void Main(string[] args)
    {
        int num, i, multiplo;

        Console.WriteLine("¡Hola! Yo soy un programa que te mostrará los primeros 20 múltiplos de un número");

        Console.WriteLine("Ingrese un numero:");
        num = int.Parse(Console.ReadLine());

        for (i = 1; i <= 20; i++)
        {
            multiplo = num * i;

            Console.WriteLine(multiplo);
        }
    }

}