﻿internal class Program
{
    private static void Main(string[] args)
    {
        int i;

        Console.WriteLine("Números Impares");
        Console.WriteLine("Para mostrar los números impares hasta el 100, presione ENTER");
        Console.ReadKey();

        for (i = 1; i <= 100; i = i + 2)
        {
            Console.WriteLine(i);
        }

    }
}