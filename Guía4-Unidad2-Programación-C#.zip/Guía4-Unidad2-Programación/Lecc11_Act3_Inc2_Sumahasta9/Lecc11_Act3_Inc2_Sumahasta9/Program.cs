﻿internal class Program
{
    private static void Main(string[] args)
    {
        int num, suma;

        suma = 0;

        Console.WriteLine("Suma de los números");

        do
        {
            Console.WriteLine("Ingrese un numero:");
            num = int.Parse(Console.ReadLine());

            suma = suma + num;

        } while (num != 9);

        Console.WriteLine("La suma total es: " + suma);
    }
}