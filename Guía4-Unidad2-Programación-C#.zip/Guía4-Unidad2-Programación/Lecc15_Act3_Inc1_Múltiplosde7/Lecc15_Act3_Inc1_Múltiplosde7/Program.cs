﻿internal class Program
{
    private static void Main(string[] args)
    {
        int i, multiplo, suma, pares;

        suma = 0;
        pares = 0;

        Console.WriteLine("¡Bienvenido! Para mostrar los múltiplos de 7 y su suma, presiona ENTER");
        Console.ReadKey();

        for (i = 1; i <= 20; i++)
        {
            multiplo = i * 7;

            Console.WriteLine(multiplo);

            suma = suma + multiplo;

            if (multiplo % 2 == 0)
            {
                pares++;
            }
        }

        Console.WriteLine("La suma de los multiplos es: " + suma);
        Console.WriteLine("Si quieres saber cuántos múltiplos son pares, presiona SPACE");
        Console.ReadKey();
        Console.WriteLine("Cantidad de multiplos pares: " + pares);
    }
}