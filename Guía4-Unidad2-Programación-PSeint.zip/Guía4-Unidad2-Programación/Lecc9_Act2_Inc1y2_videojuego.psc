Algoritmo Lecc9_Act2_Inc1y2_videojuego
	definir monedas, nivel, ganancia Como Entero
	monedas = 0;
	Escribir "*****************WELCOME TO TEMPLE RUN****************"
	Escribir "�Quieres subir de nivel? �Dime cu�ntas monedas has ganado!"
	leer monedas
	
	Mientras monedas < 350  Hacer
		Escribir "Nivel 5 BLOQUEADO, tienes: ",monedas," monedas."
		Escribir "Ingresa cu�ntas monedas ganaste en esta partida: "
		leer ganancia
		
		monedas = monedas + ganancia
	Fin Mientras
	
	Escribir "�Felicidades! Tienes ",monedas," monedas."
	Escribir "�Has desbloqueado el nivel 5!"
FinAlgoritmo
