Algoritmo Lecc23_Act4_Inc1_Multiplicaci�n
	Definir num, i, resultado Como Entero
	
    Escribir "�Bienvenido!"
	
    Escribir "Ingresa un numero y te mostrar� la tabla :)"
    Leer num
	
    Para i <- 1 Hasta 10 Hacer
		
        resultado <- num * i
		
        Escribir num, " x ", i, " = ", resultado
		
    FinPara

FinAlgoritmo
