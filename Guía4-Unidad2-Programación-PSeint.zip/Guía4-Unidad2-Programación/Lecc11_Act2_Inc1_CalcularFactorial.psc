Algoritmo Lecc11_Act2_Inc1_CalcularFactorial
	Definir num, i, factorial Como Entero
	
    factorial <- 1
	
	Escribir "�Encuentra el factorial de un n�mero!"
    Escribir "Ingrese un numero:"
    Leer num
	
    Para i <- 1 Hasta num Hacer
		
        factorial <- factorial * i
		
    FinPara
	
    Escribir "El factorial es: ", factorial

FinAlgoritmo
