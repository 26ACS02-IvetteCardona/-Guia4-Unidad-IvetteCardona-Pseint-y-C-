Algoritmo Lecc24_Act3_Inc1_SumarnumPrimos
	Definir num, i, contador, suma Como Entero
	
    suma <- 0
	
    Escribir "N�meros primos del 1 al 50 y su suma"
	
    Para num <- 1 Hasta 50 Hacer
		
        contador <- 0
		
        Para i <- 1 Hasta num Hacer
			
            Si num MOD i = 0 Entonces
				
                contador <- contador + 1
				
            FinSi
			
        FinPara
		
        Si contador = 2 Entonces
			
            Escribir "Numero primo: ", num
			
            suma <- suma + num
			
        FinSi
		
    FinPara
	
    Escribir "La suma de los numeros primos es: ", suma

FinAlgoritmo
