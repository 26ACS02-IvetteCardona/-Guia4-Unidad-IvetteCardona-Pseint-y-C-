Algoritmo Lecc10_Act2_Inc1_M�ltiplosdeCuatro
	Definir num Como Entero
	
    Escribir "Nombre: M�ltiplos de 4"
	
    Para num <- 1 Hasta 20 Hacer
		
        Escribir num * 4
		
    FinPara

FinAlgoritmo
