Algoritmo Lecc9_Act3_Inc1_EnterosImpares
	Definir N, contador Como Entero
	
	Escribir "Ingresa un n�mero que sea mayor a 20: "
	leer N
	
	contador = 20
	
	Mientras contador <= N Hacer
		Si contador %2 <> 0 Entonces
			Escribir Contador
		Fin Si
		contador = contador +1
	Fin Mientras

FinAlgoritmo
