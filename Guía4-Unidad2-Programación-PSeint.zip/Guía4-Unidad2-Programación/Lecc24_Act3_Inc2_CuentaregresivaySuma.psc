Algoritmo Lecc24_Act3_Inc2_CuentaregresivaySuma
	Definir num, i, suma Como Entero
	
    suma <- 0
	
    Escribir "�Bienvenid@! Para hacerme funcionar, presiona SPACE"
	Esperar Tecla
	
    Escribir "Ingrese un numero:"
    Leer num
	
    Para i <- num Hasta 1 Con Paso -1 Hacer
		
        Escribir i
		
        suma <- suma + i
		
    FinPara
	
    Escribir "La suma es: ", suma
FinAlgoritmo
