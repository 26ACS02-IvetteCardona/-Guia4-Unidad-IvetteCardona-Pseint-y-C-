Algoritmo Lecc24_Act2_Inc1_20M�ltiplos
	Definir num, i, multiplo Como Entero
	
    Escribir "�Hola! Yo soy un programa que te mostrar� los primeros 20 m�ltiplos de un n�mero"
	
    Escribir "Ingrese un numero:"
    Leer num
	
    Para i <- 1 Hasta 20 Hacer
		
        multiplo <- num * i
		
        Escribir multiplo
		
    FinPara
FinAlgoritmo
