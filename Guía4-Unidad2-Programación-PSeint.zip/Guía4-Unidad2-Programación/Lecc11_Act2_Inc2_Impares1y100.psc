Algoritmo Lecc11_Act2_Inc2_Impares1y100
	Definir i Como Entero
	
    Escribir "N�meros Impares"
	Escribir "Para mostrar los n�meros impares hasta el 100, presione ENTER"
	Esperar Tecla
	
    Para i <- 1 Hasta 100 Con Paso 2 Hacer
		
        Escribir i
		
    FinPara
FinAlgoritmo
