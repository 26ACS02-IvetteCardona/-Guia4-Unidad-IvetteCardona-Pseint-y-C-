Algoritmo Lecc15_Act2_Inc1_ContadorysumadePrimos
	Definir num, i, contador, cantidad, suma Como Entero
	
    cantidad <- 0
    suma <- 0
	
    Escribir "Para saber cu�ntos n�meros primos hay entre 1 y 100, presiona SPACE"
	Esperar Tecla
	
    Para num <- 1 Hasta 100 Hacer
		
        contador <- 0
		
        Para i <- 1 Hasta num Hacer
			
            Si num MOD i = 0 Entonces
				
                contador <- contador + 1
				
            FinSi
			
        FinPara
		
        Si contador = 2 Entonces
			
            cantidad <- cantidad + 1
            suma <- suma + num
			
        FinSi
		
    FinPara
	
    Escribir "Cantidad de numeros primos: ", cantidad
	Escribir "Para saber la suma de los n�meros, presiona el signo +"
	Esperar Tecla
    Escribir "La suma de los numeros primos es: ", suma

FinAlgoritmo
