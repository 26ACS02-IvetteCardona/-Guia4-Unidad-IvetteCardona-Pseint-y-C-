Algoritmo Lecc10_Act1_Inc1_Cuponera
	Definir corte Como Entero 
	
	Escribir "Nombre: Ivette Cardona" 
	
	Para corte <- 1 Hasta 8 Con Paso 1 Hacer 
		Escribir "Presione 0 para marcar su sello en la cuponera"
		Esperar Tecla
		Escribir "Sello obtenido en el corte: ", corte 
		
	FinPara 
	
	Escribir "Obtener corte gratis" 

	
FinAlgoritmo
