Algoritmo Lecc10_Act2_Inc2_EnterosPares
	Definir num, i Como Entero
	
    Escribir "Ingrese un numero:"
    Leer num
	
    Para i <- 2 Hasta num Con Paso 2 Hacer
		
        Escribir i
		
    FinPara
FinAlgoritmo
