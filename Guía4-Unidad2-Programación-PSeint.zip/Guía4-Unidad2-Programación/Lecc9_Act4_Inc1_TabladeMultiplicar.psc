Algoritmo Lecc9_Act4_Inc1_TabladeMultiplicar
	Definir num, contador, resultado Como Entero
	
	Escribir "Dime el n�mero para brindarte la tabla: "
	leer num
	
	contador = 1
	
	Mientras contador <= 10  Hacer
		resultado = num * contador
		Escribir num, " x ", contador, " = ", resultado
		
		contador = contador + 1
	Fin Mientras
	
FinAlgoritmo
