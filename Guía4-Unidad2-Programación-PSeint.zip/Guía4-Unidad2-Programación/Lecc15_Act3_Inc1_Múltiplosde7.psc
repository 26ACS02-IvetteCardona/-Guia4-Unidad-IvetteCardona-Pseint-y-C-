Algoritmo Lecc15_Act3_Inc1_M�ltiplosde7
	Definir i, multiplo, suma, pares Como Entero
	
    suma <- 0
    pares <- 0
	
    Escribir "�Bienvenido! Para mostrar los m�ltiplos de 7 y su suma, presiona ENTER"
	Esperar Tecla
	
    Para i <- 1 Hasta 20 Hacer
		
        multiplo <- i * 7
		
        Escribir multiplo
		
        suma <- suma + multiplo
		
        Si multiplo MOD 2 = 0 Entonces
			
            pares <- pares + 1
			
        FinSi
		
    FinPara
	
    Escribir "La suma de los multiplos es: ", suma
	Escribir "Si quieres saber cu�ntos m�ltiplos son pares, presiona SPACE"
	Esperar Tecla
    Escribir "Cantidad de multiplos pares: ", pares

FinAlgoritmo
