Algoritmo Lecc11_Act1_Inc1_Estacionamiento
	Definir cajones Como Entero
	
    cajones <- 200
	
    Escribir "Estacionamiento Libre"
	
    Repetir
		
		Escribir "Si desea saber cu�ntos estacionamientos quedan libres, presione ENTER"
		Esperar Tecla
        Escribir "Cajones disponibles: ", cajones
		
        cajones <- cajones - 1
		
    Hasta Que cajones = 0
	
    Escribir "Ya no hay cajones libres"

FinAlgoritmo
