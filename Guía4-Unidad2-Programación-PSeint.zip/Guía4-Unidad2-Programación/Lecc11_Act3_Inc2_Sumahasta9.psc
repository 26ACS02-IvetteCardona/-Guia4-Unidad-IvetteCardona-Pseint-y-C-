Algoritmo Lecc11_Act3_Inc2_Sumahasta9
	Definir num, suma Como Entero
	
    suma <- 0
	
    Escribir "Suma de los n�meros"
	
    Repetir
		
        Escribir "Ingrese un numero:"
        Leer num
		
        suma <- suma + num
		
    Hasta Que num = 9
	
    Escribir "La suma total es: ", suma

FinAlgoritmo
