Algoritmo Lecc9_Act3_Inc2_NumerosPrimos
	Definir num, div, cantdiv Como Entero
	
	Escribir "Ingresa un n�mero positivo y entero: "
	leer num
	
	div = 1
	cantdiv = 0
	
	Mientras div <= num Hacer
		Si num % div = 0 Entonces
			cantdiv = cantdiv + 1
		Fin Si
		div = div +1
	Fin Mientras
	
	Si cantdiv = 2 Entonces
		Escribir "El n�mero ",num," es Primo"
	SiNo
		Escribir "El n�mero ",num," NO es Primo"
	Fin Si
FinAlgoritmo
