Algoritmo Lecc10_Act3_Inc1_SumaN�merosPrimos
	Definir num, i, contador, suma Como Entero
    suma <- 0
	
    Escribir "Presione ENTER para mostrar los n�meros primos del 1 al 22"
	Esperar Tecla
	
    Para num <- 1 Hasta 22 Hacer
		
        contador <- 0
		
        Para i <- 1 Hasta num Hacer
			
            Si num MOD i = 0 Entonces
                contador <- contador + 1
            FinSi
			
        FinPara
		
        Si contador = 2 Entonces
			
            Escribir "Numero primo: ", num
			
            suma <- suma + num
			
        FinSi
		
    FinPara
	
	Escribir "Presione S para mostrar la suma de los n�meros"
	Esperar Tecla
    Escribir "La suma de los numeros primos es: ", suma
FinAlgoritmo
