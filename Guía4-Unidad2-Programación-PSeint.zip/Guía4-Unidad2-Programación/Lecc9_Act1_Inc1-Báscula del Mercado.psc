Algoritmo Lecc9_Act1_Inc1
	Definir pesoAcumulado, pesoManzana, contarmanzanas Como Real
	pesoAcumulado=0;
	contarmanzanas=0;
	
	Escribir "*=================B�SCULA DEL MERCADO=================*"
	Mientras pesoAcumulado<1000 Hacer
		Escribir "Ingrese el peso de la manzana en gramos (100-300)"
		leer pesoManzana
		
		Si pesoManzana>=100 y pesoManzana<=300 Entonces
			pesoAcumulado = pesoAcumulado+pesoManzana
			Escribir "Peso Actual: ",pesoAcumulado," gramos"
			contarmanzanas=contarmanzanas+1
		SiNo
			Escribir "Error: Esa manzana no cumple con el peso solicitado"
		Fin Si
	Fin Mientras
	
	Escribir "�Meta alcanzada! Ya tiene ",pesoAcumulado/1000," kilos en la bolsa."
	Escribir "Usted acumulo ",contarmanzanas," manzanas"
FinAlgoritmo
